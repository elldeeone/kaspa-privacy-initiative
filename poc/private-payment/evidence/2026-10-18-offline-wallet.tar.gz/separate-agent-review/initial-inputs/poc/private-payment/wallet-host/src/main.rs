mod fixture;
mod proof;
mod state;
mod scan;
mod adversarial;
use anyhow::{ensure,Result};
use std::path::Path;
fn main()->Result<()> {
    let a:Vec<_>=std::env::args().collect();ensure!(a.len()>=2,"prepare PROGRAM NEW_DIR | profile/prove CASE NEW_OUT | verify CASE RECEIPT NEW_OUT");
    match a[1].as_str(){
        "check-native" if a.len()==4=>adversarial::run(Path::new(&a[2]),Path::new(&a[3])),
        "prepare" if a.len()==4=>fixture::prepare(Path::new(&a[2]),Path::new(&a[3])),
        "profile"|"prove" if a.len()==4=>proof::run(&a[1],Path::new(&a[2]),None,Path::new(&a[3])),
        "verify" if a.len()==5=>proof::run("verify",Path::new(&a[2]),Some(Path::new(&a[3])),Path::new(&a[4])),
        _=>anyhow::bail!("invalid command"),
    }
}
