// CPU-only two-real-input TRANSFER/current-spentness probe; public files only.
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/fixture.rs"] mod fixture;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/canonical-receipt-inputs/source/poc/private-payment/wallet-host/src/proof.rs"] mod proof;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/state.rs"] mod state;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/scan.rs"] mod scan;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/canonical-receipt-inputs/source/poc/private-payment/wallet-host/src/history.rs"] mod history;
use anyhow::{ensure,Result};
use kpi_wallet_core::*;
use std::{fs,path::Path};
fn main()->Result<()> {
 let root=Path::new("/tmp/kpi-offline-wallet-code-review-20261018/transfer-runtime-inputs");
 let raw=fs::read(root.join("transfer-history.json"))?;
 ensure!(hex::encode(hash(&raw))=="09bf10cd181357d636ae26d1de9d62ad9ee8396773fdd5502dc60367a60b625d","baseline history identity mismatch");
 let (mut state,accepted)=history::replay(&raw,&hash(&raw),&root.join("proofs"))?;
 ensure!(accepted.len()==2&&state.cursor==2&&state.private==1000&&state.reserve==1000&&state.pending==0&&state.exits==0&&state.fees==0&&state.tree.leaves.len()==4&&state.spent.len()==4&&state.allowed.len()==3,"two-receipt admission mismatch");
 let original_commitment=hex::encode(state.commitment());
 ensure!(original_commitment=="3161ea8cf1b098b9217f890236d3a784849d69fffbc228378b21db6053a0b10c","baseline state mismatch");
 let intent_raw=fs::read(root.join("cases/transfer/intent.bin"))?;
 let i=Intent::decode(&intent_raw)?;let auth=fs::read(root.join("cases/transfer/authorization.bin"))?;
 let journal=fs::read(root.join("cases/transfer/expected-journal.bin"))?;
 ensure!(i==accepted[1]&&i.journal(&auth)?==journal&&hex::encode(hash(&journal))=="1e9dc3c5e4ce746395a81367007b22668d0158faf5c3c48fb6a629a2a1d0e420","transfer public transcript mismatch");
 let receipt=history::load_receipt(&root.join("proofs"),"transfer","85f1b62ffbbb3ad1f97df28fa1cb07a36a6418f55d9ef6e9d5be408e57995964")?;
 let image=risc0_zkvm::sha::Digest::try_from(state.ids[7].as_slice())?;
 proof::verify(&receipt,image,&journal)?;
 ensure!(state.allowed.contains(&i.anchor)&&state.tree.root_path(None)?.0!=i.anchor,"transfer is not an old allowed-anchor control");
 let economic=state.economic_bytes();let (ok,reason)=state.apply(&intent_raw,&auth,&receipt)?;
 ensure!(!ok&&reason=="already spent nullifier"&&economic==state.economic_bytes()&&state.cursor==3,"stale-anchor transfer replay changed economics");
 ensure!(hex::encode(state.commitment())=="c6bd748932409b6eb193c24368a9ea35da4106ac25b4ccb8e4195f0daa749ffa","duplicate history state mismatch");
 println!("{}",serde_json::to_string_pretty(&serde_json::json!({"scope":"SEPARATE_AGENT_SAME_BACKEND_PUBLIC_TRANSFER_RECEIPT_AND_CURRENT_SPENTNESS","realReceiptsAdmitted":2,"transferReceiptCpuVerified":true,"canonicalReceiptProfileChecked":true,"staleAnchorStillAllowed":true,"duplicateTransferRejectReason":reason,"rejectionEconomicallyAtomic":true,"baselineStateCommitment":original_commitment,"duplicateStateCommitment":hex::encode(state.commitment()),"cursorAfterDuplicate":state.cursor,"nullifiers":state.spent.len(),"leaves":state.tree.leaves.len(),"privateSompi":state.private,"reserveSompi":state.reserve,"privateFilesRead":false,"gpuUsed":false,"nativeTransactions":0}))?);Ok(())
}
