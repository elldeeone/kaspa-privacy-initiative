// Final CPU-only public replay/current-spentness check. No backup/witness reads.
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/fixture.rs"] mod fixture;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/canonical-receipt-inputs/source/poc/private-payment/wallet-host/src/proof.rs"] mod proof;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/state.rs"] mod state;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/scan.rs"] mod scan;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/canonical-receipt-inputs/source/poc/private-payment/wallet-host/src/history.rs"] mod history;
use anyhow::{ensure,Result};
use kpi_wallet_core::*;
use std::{fs,path::Path};

fn replay(root:&Path,label:&str)->Result<(state::State,Vec<Intent>,history::History)> {
 let selected:serde_json::Value=serde_json::from_slice(&fs::read(root.join("selected-histories.json"))?)?;
 let selected=&selected[label];let raw=fs::read(root.join(selected["history"].as_str().unwrap()))?;
 let pin:[u8;32]=hex::decode(selected["sha256"].as_str().unwrap())?.try_into().unwrap();
 let report:serde_json::Value=serde_json::from_slice(&fs::read(root.join(selected["report"].as_str().unwrap()))?)?;
 ensure!(report["historySha256"]==hex::encode(pin),"owner-selected pin mismatch");
 let(s,accepted)=history::replay(&raw,&pin,&root.join("proofs"))?;
 ensure!(report["stateCommitment"]==hex::encode(s.commitment())&&report["acceptedWalletOperations"]==accepted.len()&&report["cursor"]==s.cursor&&report["privateLiabilitiesSompi"]==s.private&&report["unpaidExitSompi"]==s.exits&&report["reserveSompi"]==s.reserve&&report["nullifiers"]==s.spent.len()&&report["leaves"]==s.tree.leaves.len(),"public report not reproduced by frozen modules");
 let h:history::History=serde_json::from_slice(&raw)?;Ok((s,accepted,h))
}

fn main()->Result<()> {
 let root=Path::new("/tmp/kpi-offline-wallet-code-review-20261018/final-runtime-inputs");
 let(s,accepted,h)=replay(root,"final")?;
 ensure!(h.records.len()==4&&accepted.len()==4&&s.cursor==4,"four-receipt final history incomplete");
 ensure!(accepted.iter().map(|i|i.kind).collect::<Vec<_>>()==[0,1,2,2]&&accepted.iter().map(|i|i.mode).collect::<Vec<_>>()==[0,0,1,1],"unexpected final lifecycle shape");
 ensure!(s.pending==0&&s.private==0&&s.exits==1000&&s.fees==0&&s.reserve==1000&&s.spent.len()==8&&s.tree.leaves.len()==4&&s.allowed.len()==3&&s.claims.len()==2,"final backing/nullifier/append/claim mismatch");s.reconcile()?;
 let image=risc0_zkvm::sha::Digest::try_from(s.ids[7].as_slice())?;
 ensure!(image.to_string()=="7461de1c1231e61823431d4800d70f1d8378cf7722b195e82321a028151b2ade","unreviewed guest image");
 let mut receipts=Vec::new();let mut duplicate_results=Vec::new();
 for (j,record) in h.records.iter().enumerate() {
  let receipt=history::load_receipt(&root.join("proofs"),&record.name,&record.receipt_sha256)?;
  let raw_intent=hex::decode(&record.intent)?;let i=Intent::decode(&raw_intent)?;let auth=hex::decode(&record.authorization)?;
  let case=root.join("cases").join(&record.name);
  ensure!(fs::read(case.join("intent.bin"))?==raw_intent&&fs::read(case.join("authorization.bin"))?==auth&&fs::read(case.join("expected-journal.bin"))?==i.journal(&auth)?,"public case/accepted transcript mismatch");
  proof::verify(&receipt,image,&i.journal(&auth)?)?;
  ensure!(receipt.inner.verifier_parameters().to_string()=="ece5e9b8ae2cd6ea6b1827b464ff0348f9a7f4decd269c0087fdfd75098da013","verifier parameters changed");
  receipts.push(serde_json::json!({"case":record.name,"receiptSha256":record.receipt_sha256,"publicJournalSha256":hex::encode(hash(&i.journal(&auth)?)),"canonicalCpuReceiptVerified":true}));
  if j>0 {ensure!(s.allowed.contains(&i.anchor),"replay root unexpectedly unavailable");let mut duplicate=s.clone();let before=duplicate.economic_bytes();let(ok,reason)=duplicate.apply(&raw_intent,&auth,&receipt)?;ensure!(!ok&&reason=="already spent nullifier"&&duplicate.economic_bytes()==before&&duplicate.cursor==s.cursor+1,"final replay not rejected atomically by spentness");duplicate_results.push(serde_json::json!({"case":record.name,"reason":reason,"economicStateUnchanged":true}));}
 }
 let(mixed,mixed_accepted,mixed_history)=replay(root,"mixed")?;
 ensure!(mixed_history.records.len()==mixed_accepted.len()+1&&[3,4].contains(&mixed_accepted.len()),"mixed history lacks exactly one false proof control");
 let policy=Intent::decode(&hex::decode(&mixed_history.synthetic_policy_credit_intent)?)?;
 let mut manual=state::State::genesis(&policy)?;let mut outcomes=Vec::new();
 for (j,record) in mixed_history.records.iter().enumerate() {
  let raw_intent=hex::decode(&record.intent)?;let i=Intent::decode(&raw_intent)?;let auth=hex::decode(&record.authorization)?;let receipt=history::load_receipt(&root.join("proofs"),&record.name,&record.receipt_sha256)?;let before=manual.economic_bytes();let ordinal=manual.cursor;let(ok,_)=manual.apply(&raw_intent,&auth,&receipt)?;
  if j==1 {ensure!(!ok&&before==manual.economic_bytes()&&proof::verify(&receipt,image,&i.journal(&auth)?).is_err(),"well-formed false proof was not an economic no-op");} else {ensure!(ok,"genuine mixed-history operation failed");}
  ensure!(manual.cursor==ordinal+1,"mixed cursor omission");outcomes.push(ok);
 }
 ensure!(manual.commitment()==mixed.commitment(),"mixed sequential replay mismatch");
 let public_exit_sum=mixed_accepted.iter().try_fold(0u64,|n,i|n.checked_add(i.exited).ok_or_else(||anyhow::anyhow!("exit sum overflow")))?;
 ensure!(mixed.pending==0&&mixed.fees==0&&mixed.exits==public_exit_sum&&mixed.private.checked_add(mixed.exits)==Some(1000)&&mixed.reserve==1000,"mixed branch conservation mismatch");
 println!("{}",serde_json::to_string_pretty(&serde_json::json!({"scope":"FINAL_SEPARATE_AGENT_SAME_BACKEND_PUBLIC_CPU_RUNTIME_NOT_PROVED_OUTER_OR_NATIVE","actualWalletImage":image.to_string(),"fourRealReceipts":receipts,"finalStateCommitment":hex::encode(s.commitment()),"finalCursor":s.cursor,"privateSompi":s.private,"unpaidExitSompi":s.exits,"reserveSompi":s.reserve,"nullifiers":s.spent.len(),"leaves":s.tree.leaves.len(),"allowedAnchors":s.allowed.len(),"unpaidClaims":s.claims.len(),"finalReplayRejections":duplicate_results,"mixedStateCommitment":hex::encode(mixed.commitment()),"mixedOutcomes":outcomes,"mixedPrivateSompi":mixed.private,"mixedExitSompi":mixed.exits,"privateFilesRead":false,"gpuUsed":false,"nativeTransactions":0}))?);Ok(())
}
