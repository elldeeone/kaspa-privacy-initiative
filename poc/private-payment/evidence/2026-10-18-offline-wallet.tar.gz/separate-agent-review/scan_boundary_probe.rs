// Reviewer-only boundary probe. Reads unfunded local research witnesses in memory;
// emits only booleans/counts. No secret material is copied into this directory.
#[path="/tmp/kpi-offline-wallet-code-review-20261018/poc/private-payment/wallet-host/src/fixture.rs"] mod fixture;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/poc/private-payment/wallet-host/src/proof.rs"] mod proof;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/poc/private-payment/wallet-host/src/state.rs"] mod state;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/poc/private-payment/wallet-host/src/scan.rs"] mod scan;
use anyhow::{ensure,Result};
use kpi_wallet_core::*;
use std::{fs,path::Path};
fn main()->Result<()> {
 let root=Path::new("/tmp/kpi-offline-wallet-cyuo2yo8/cases");
 let read=|name:&str|Witness::decode(&fs::read(root.join(name).join("input.bin"))?);
 let credit=read("credit")?;let transfer=read("transfer")?;let exit=read("exit")?;
 for w in [&credit,&transfer,&exit]{validate(w)?;}
 let recipient_key=transfer.old[0].sk;
 let mut s=state::State::genesis(&credit.intent)?;
 for w in [&credit,&transfer,&exit]{s.spent.extend(w.intent.nf);s.tree.append(&w.intent);s.allowed.insert(s.tree.root_path(None)?.0);}
 let history=vec![credit.intent,transfer.intent,exit.intent];
 let baseline=scan::scan(&[recipient_key],&history,&s)?;
 ensure!(baseline.len()==1,"expected one unspent fixture output");
 let mut changed=history.clone();changed[1].ciphertext[1][52]^=1;
 let silently_empty=scan::scan(&[recipient_key],&changed,&s)?.is_empty();
 ensure!(silently_empty,"probe no longer demonstrates scan boundary issue");
 let duplicate_keys_duplicate_notes=scan::scan(&[recipient_key,recipient_key],&history,&s)?.len()==2;
 ensure!(duplicate_keys_duplicate_notes,"probe no longer demonstrates key inventory issue");
 let mut malformed=history[1].clone();malformed.ids[0].clear();
 let original_hook=std::panic::take_hook();std::panic::set_hook(Box::new(|_|{}));
 let helper_panics=std::panic::catch_unwind(||malformed.journal(&[0])).is_err();
 std::panic::set_hook(original_hook);ensure!(helper_panics,"helper no longer panics");
 println!("{{\"scope\":\"SCANNER_BOUNDARY_ONLY_NOT_VERIFIED_HISTORY_DRIVER\",\"validRelationInputs\":3,\"sameLengthCiphertextMutationReturnsEmpty\":true,\"duplicateKeyDuplicatesOwnedNote\":true,\"directMalformedIntentJournalPanics\":true,\"secretsPublished\":false}}");
 Ok(())
}
