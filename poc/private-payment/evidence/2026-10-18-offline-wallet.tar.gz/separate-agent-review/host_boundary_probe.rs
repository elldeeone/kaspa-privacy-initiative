// Public, unfunded source-boundary checks. No backup/witness files are read.
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/fixture.rs"] mod fixture;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/proof.rs"] mod proof;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/state.rs"] mod state;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/scan.rs"] mod scan;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/history.rs"] mod history;
fn main() {
 let mut b=fixture::Backup {profile:"OFFLINE_ONLY_PLAINTEXT_RESEARCH_BACKUP_V1".into(),context:vec![],orchard_keys:vec!["ab".repeat(32)],pending_deposit_seed:None,pending_deposit_reference:None};
 assert_eq!(history::keys(&b).unwrap().len(),1);
 b.orchard_keys.push("ab".repeat(32));assert!(history::keys(&b).is_err());
 b.orchard_keys[1]="AB".repeat(32);assert!(history::keys(&b).is_err());
 b.orchard_keys.clear();assert!(history::keys(&b).is_err());
 let mut counts=0;
 for count in [0,(1u64<<32)-2,(1u64<<32)-1,1u64<<32,(1u64<<32)+1,u64::MAX] {for mode in [0,1] {
  let expected=count<=(1u64<<32)&&(mode==1||count<=(1u64<<32)-2);
  assert_eq!(state::capacity(count,mode).is_ok(),expected);counts+=1;
 }}
 assert!(state::capacity(0,2).is_err());
 println!("{{\"scope\":\"PUBLIC_HOST_BOUNDARY_HELPERS_NO_RECEIPT_OR_RESTORE_RUNTIME_CLAIM\",\"duplicateAndAliasKeysRejected\":true,\"emptyKeyInventoryRejected\":true,\"capacityBoundaries\":{counts},\"unknownModeRejected\":true,\"privateFilesRead\":false}}");
}
