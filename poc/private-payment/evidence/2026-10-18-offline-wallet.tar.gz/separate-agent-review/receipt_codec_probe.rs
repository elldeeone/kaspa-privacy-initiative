// Public receipt encoding probe, CPU-only. No witness or backup access.
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/fixture.rs"] mod fixture;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/duplicate-receipt-inputs/source/poc/private-payment/wallet-host/src/proof.rs"] mod proof;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/state.rs"] mod state;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/final-inputs-v2/poc/private-payment/wallet-host/src/scan.rs"] mod scan;
#[path="/tmp/kpi-offline-wallet-code-review-20261018/duplicate-receipt-inputs/source/poc/private-payment/wallet-host/src/history.rs"] mod history;
use anyhow::{ensure,Result};
use kpi_wallet_core::*;
use risc0_zkvm::Receipt;
use std::{fs,path::Path};
fn main()->Result<()> {
 let root=Path::new("/tmp/kpi-offline-wallet-code-review-20261018");
 let frozen=root.join("credit-runtime-inputs");
 let raw=fs::read(frozen.join("proofs/credit/proof/wallet-receipt.bin"))?;
 let decoded:Receipt=bincode::deserialize(&raw)?;
 ensure!(bincode::serialize(&decoded)?==raw,"original receipt not canonical under selected writer");
 let i=Intent::decode(&fs::read(frozen.join("cases/credit/intent.bin"))?)?;
 let auth=fs::read(frozen.join("cases/credit/authorization.bin"))?;
 let image=risc0_zkvm::sha::Digest::try_from(i.ids[7].as_slice())?;
 let journal=i.journal(&auth)?;let out=root.join("receipt-codec-probe");fs::create_dir(&out)?;
 let mut baseline=state::State::genesis(&i)?;ensure!(baseline.apply(&i.encode()?,&auth,&decoded)?.0,"baseline failed");
 let mut cases=Vec::new();
 for (n,suffix) in [vec![0],vec![255;32],raw.clone()].into_iter().enumerate() {
  let mut altered=raw.clone();altered.extend(&suffix);
  let name=format!("alias-{n}");let p=out.join(&name).join("proof");fs::create_dir_all(&p)?;fs::write(p.join("wallet-receipt.bin"),&altered)?;
  ensure!(history::load_receipt(&out,&name,&hex::encode(hash(&raw))).is_err(),"original pinned receipt hash ignored");
  let alias=history::load_receipt(&out,&name,&hex::encode(hash(&altered)))?;
  proof::verify(&alias,image,&journal)?;
  let canonical=bincode::serialize(&alias)?;
  ensure!(canonical==raw&&canonical!=altered,"trailing alias unexpectedly canonical");
  let mut s=state::State::genesis(&i)?;ensure!(s.apply(&i.encode()?,&auth,&alias)?.0,"alias rejected by existing typed state adapter");
  ensure!(s.commitment()==baseline.commitment(),"typed canonical state differs");
  cases.push(serde_json::json!({"trailingBytes":suffix.len(),"rawSha256":hex::encode(hash(&altered)),"existingLoaderAcceptsRehashedAlias":true,"actualReceiptVerifies":true,"roundtripEqualityWouldReject":true,"originalPinRejects":true,"sameLogicalStateCommitment":true}));
 }
 println!("{}",serde_json::to_string_pretty(&serde_json::json!({"scope":"PUBLIC_RECEIPT_TRAILING_ENCODING_ALIASES_NOT_THEFT_OR_NATIVE_R13","canonicalOriginalReceipt":true,"aliases":cases,"privateFilesRead":false,"gpuUsed":false,"nativeTransactions":0}))?);Ok(())
}
