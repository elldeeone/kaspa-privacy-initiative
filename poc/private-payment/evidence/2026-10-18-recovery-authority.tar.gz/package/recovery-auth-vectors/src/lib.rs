//! P1 public primitive input-policy prototype. No native or wallet authority.
use anyhow::{ensure, Context, Result};
use curve25519_dalek::{edwards::CompressedEdwardsY, scalar::Scalar};
use ed25519_dalek::{Signature, VerifyingKey};

pub const CREDIT_TAG: &[u8] = b"KPI/credit-recovery/v1";

/// Existing point APIs only. to_bytes() on VerifyingKey preserves its input;
/// canonicality must compare the decompressed point's recompression instead.
pub fn canonical_point(bytes: &[u8]) -> Result<()> {
    let raw: [u8; 32] = bytes.try_into().context("point length")?;
    let point = CompressedEdwardsY(raw)
        .decompress()
        .context("invalid point")?;
    ensure!(point.compress().to_bytes() == raw, "noncanonical point");
    ensure!(
        !point.is_small_order() && point.is_torsion_free(),
        "non-prime-order point"
    );
    Ok(())
}

pub fn verify_profile(public_key: &[u8], message: &[u8], signature: &[u8]) -> Result<()> {
    let pk: [u8; 32] = public_key.try_into().context("public key length")?;
    let sig: [u8; 64] = signature.try_into().context("signature length")?;
    canonical_point(&pk)?;
    canonical_point(&sig[..32])?;
    ensure!(
        bool::from(Scalar::from_canonical_bytes(sig[32..].try_into()?).is_some()),
        "noncanonical signature scalar"
    );
    VerifyingKey::from_bytes(&pk)?.verify_strict(message, &Signature::from_bytes(&sig))?;
    Ok(())
}

/// A proposed tagged tuple, not proof that the supplied key owns a deposit.
pub fn credit_message(genesis_descriptor_hash: &[u8; 32], intent_id: &[u8; 32]) -> Vec<u8> {
    [
        CREDIT_TAG,
        genesis_descriptor_hash.as_slice(),
        intent_id.as_slice(),
    ]
    .concat()
}
