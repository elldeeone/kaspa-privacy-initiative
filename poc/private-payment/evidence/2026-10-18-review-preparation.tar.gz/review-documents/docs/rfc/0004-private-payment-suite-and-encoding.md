# RFC-0004: Candidate private-payment primitive suite and public intent bytes

Status: Open, 2026-10-18. Implementation/review package for
[RFC-0003](0003-private-payment-proof-and-settlement.md), under
[ADR-0018](../adr/0018-private-payment-implementation-package.md).
This is an unreviewed candidate, not an accepted private wallet circuit or
native deposit contract. Independent composition review and deployed artifact
identities are unresolved. Testnet execution is owner-authorized once the
actual proof/native prerequisites qualify; no mainnet or real funds.

## Primitive choices for review

- Orchard 0.16.0, exact commit `616a669df8c9a59c33d47064d3ce04b25d026b2e`.
  Existing public APIs only; no new curve/hash/AEAD/key-derivation primitive.
  V2 notes exclusively, repaired post-NU6.2 relation obligations, Pallas checked
  encodings, established spending/full-viewing/incoming hierarchy, depth-32
  Sinsemilla tree and exact note-derived nullifier. Unsupported V3 rejects.
- Require private knowledge of the full Orchard spending key and derive the
  full recipient ownership relationship. No view key or dummy spend can
  authorize another user's note or pending deposit. Initial wallets retain a
  separate independently generated spending key for the pool; seed-only
  recovery or a novel cross-pool master KDF is not introduced here.
- Incoming delivery is the complete 580-byte V2 encrypted note plus its
  32-byte ephemeral key. `rho_new[i]` is exactly slot `nf[i]`. The selected
  algorithm derives the ephemeral secret from the same seed/rho. Prove the
  entire encryption computation and ciphertext equality; trial decryption
  independently validates the recovered note. No outgoing-viewing ciphertext
  is delivered in this initial profile. That omits outgoing audit recovery,
  not incoming receipt/current spentness reconstruction. This choice requires
  composition review; it is not an unchanged Orchard bundle.
- A note value is integer sompi in u64, with checked u128 two-slot sums.
  Two action slots/dummy rules and the explicit `exit_only` adaptation preserve
  the obligations in RFC-0003; neither is established by the primitive checks.
- Recovery signatures use strict Ed25519 over the fully tagged canonical
  credit/refund tuples from RFC-0003. Exact native descriptor-to-outpoint/key
  binding remains an explicit unresolved native design requirement.
- Wallet proof candidate: RISC Zero 3.0.3 proving the full ordinary computation,
  followed by a total ordinary verifier in the outer application. The proven
  program/verification/control identities must be generated and reviewed from
  actual builds, never filled with a fabricated ID. The small proxy circuit or
  proof that a fixed public test vector computes correctly does not implement
  the private wallet relation.

The exact established algorithms are referenced by source, rather than
reimplemented as new cryptography. The package pins direct/transitive versions
for its existing-library checker. Independently reviewed wallet and outer
program artifacts, private witness packing, final native descriptor/script
binding and a full implementation are still separate deliverables.

## Candidate public intent encoding

Encode the fixed ASCII tag `KPI/private-payment/intent/v1` verbatim, followed by
the fields below in order. Integers are unsigned, fixed-width little endian.
There is no JSON serialization inside the consensus bytes. JSON hex in the
review tooling is lowercase without `0x`; it is only a human-readable fixture
boundary. A decoder rejects trailing data, unknown enums/flags, overlong/truncated
values and all semantically irrelevant kind fields.

| Field | Exact bytes |
| --- | --- |
| `G_hash`, `D`, `network_genesis`, `pool_id` | 32 each |
| `lane_id` | 20, the full native subnetwork/lane identifier |
| `statement_id`, `proof_suite_id`, `wallet_program_or_vk_hash` | 32 each |
| `operation_kind` | u8: CREDIT=0, TRANSFER=1, EXIT=2 |
| `append_mode` | u8: full=0, exit_only=1 |
| `expiry_order_bound` | option flag 0/1; if present, u64 ordinal |
| `anchor` | 32, checked canonical Orchard anchor by the actual relation |
| `nf` | two 32-byte values, slot order |
| `cmx_new` | two 32-byte values, slot order |
| `ephemeral_key` | two 32-byte values, slot order |
| `ciphertext` | two fixed 580-byte incoming ciphertexts, slot order |
| `deposit_reference` | flag 0/1; if present: native txid32, output index u32, descriptor hash32, recovery public key32 |
| `deposit_principal` | u64; zero if absent |
| `exit_script` | flag 0/1; if present: script version u16, byte length u32, script bytes |
| `exit_principal` | u64; zero if absent |
| `fee_script` | flag 0/1; if present: script version u16, byte length u32, script bytes |
| `private_fee_sompi` | u64; zero if absent |

Scripts in this candidate encoding have 1–10000 bytes. This is a review-profile
bound, not a claim about current relay/mass/consensus acceptance. Actual native
limits, destination validity, fee/rent and script version support still qualify
at P4. Empty present scripts reject. Optional absence has one encoding and is
distinct from a present zero expiry. A fee script is present exactly when the
fee is positive. CREDIT requires deposit presence/positive principal, no exit
or fee, and full mode. TRANSFER forbids deposit/exit and requires full mode.
EXIT requires a positive exit principal and destination, no deposit; it may use
either mode, with the zero-new-values predicate enforced in its private proof.

`intent_id = SHA256(the complete bytes above)`. The actual proof must bind its
entire fixed journal to that digest and descriptor/artifact IDs; hashing these
bytes alone does not establish spend authority or current state. Nullifier
uniqueness/spentness and point/scalar validity remain mandatory actual relation/
transition checks even when the public codec accepts structurally valid bytes.

The candidate deposit reference binds a **descriptor hash**, not an invented
native covenant encoding. The outer adapter must recompute it and authenticate
the exact recovery key/principal against the actual deposit outpoint. Until
the full descriptor/native binding is specified, reviewed and implemented, a
codec result cannot authorize CREDIT or refund. Golden fixtures use explicitly
synthetic descriptor/program IDs and cannot be deployed as a private pool.

## Review evidence and remaining gates

The existing-library vector checker compares public Orchard key/note/nullifier,
encryption and tree vectors against the pinned upstream implementations. A
separately pinned Zcash Python reference produces depth-32 path fixtures.
The Rust-embedded and Python encryption corpora differ in rho and derived
ciphertext bytes; both complete corpora are checked rather than reported as
identical. Primitive interoperability is not a soundness proof of a new circuit.

Before P2 substantial implementation, obtain independent review of the exact
new composition, spending-key knowledge, two-slot/dummy semantics, constrained
encryption, full-tree exit branch, domain/intent binding and deposit recovery
authority. Native descriptor linkage, actual proof artifact IDs and code-level
qualification must remain explicit until implemented/reviewed. No P1 completion
or native trial readiness follows from this document or passing codec tests.
