fn main(){ for b in orchard::Anchor::empty_tree().to_bytes(){ print!("{:02x}",b); } println!(); }
