// Public, unfunded synthetic primitive experiment. Not a wallet relation or proof.
use orchard::{keys::{SpendingKey, FullViewingKey, Diversifier, Scope}, note::{Rho, RandomSeed, NoteVersion}, value::NoteValue, Note};

fn main() {
    let sk = Option::<SpendingKey>::from(SpendingKey::from_bytes([7;32])).unwrap();
    let fvk = FullViewingKey::from(&sk);
    let other = FullViewingKey::from(&Option::<SpendingKey>::from(SpendingKey::from_bytes([9;32])).unwrap());
    let d = Diversifier::from_bytes([11;11]);
    let external = fvk.address(d, Scope::External);
    let internal = fvk.address(d, Scope::Internal);
    assert!(external != internal);
    assert_eq!(fvk.scope_for_address(&external), Some(Scope::External));
    assert_eq!(fvk.scope_for_address(&internal), Some(Scope::Internal));
    assert_eq!(other.scope_for_address(&external), None);
    assert_eq!(other.scope_for_address(&internal), None);
    let rho = Option::<Rho>::from(Rho::from_bytes(&[17;32])).unwrap();
    let seed = Option::<RandomSeed>::from(RandomSeed::from_bytes([13;32], &rho)).unwrap();
    let notes: Vec<_> = [0,1,u64::MAX].into_iter().map(|value| Option::<Note>::from(Note::from_parts(internal, NoteValue::from_raw(value), rho, seed, NoteVersion::V2)).unwrap()).collect();
    for i in 0..notes.len() {
        assert!(notes[i].nullifier(&fvk) != notes[i].nullifier(&other));
        for j in i+1..notes.len() {
            assert!(orchard::note::ExtractedNoteCommitment::from(notes[i].commitment()) != orchard::note::ExtractedNoteCommitment::from(notes[j].commitment()));
            assert!(notes[i].nullifier(&fvk) != notes[j].nullifier(&fvk));
        }
    }
    println!("public synthetic scope/ownership/zero-positive-nullifier controls passed; no proof or native payment");
}
